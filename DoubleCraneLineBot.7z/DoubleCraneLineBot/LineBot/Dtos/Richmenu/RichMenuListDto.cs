﻿namespace DoubleCraneLineBot.LineBot.Dtos
{
    public class RichMenuListDto
    {
        public List<RichMenuDto> Richmenus { get; set; }
    }
}