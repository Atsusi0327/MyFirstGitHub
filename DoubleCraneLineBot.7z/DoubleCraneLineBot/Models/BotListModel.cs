﻿namespace DoubleCraneLineBot.Models
{
    public class BotListModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public string token { get; set; }
        public string secret { get; set; }

    }
}
